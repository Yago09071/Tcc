document.addEventListener('DOMContentLoaded', () => {
    const storyText = document.getElementById('story-text');
    const choicesContainer = document.getElementById('choices-container');
    const vidasContainer = document.getElementById('vidas-container');
    const nextButton = document.getElementById('next-button');
    
    const ITEM_MACHADO = {
        bonus_ataque: 1,
        bonus_armadura: 0,
    }

    const ITEM_ESPADA_ESCUDO = {
        bonus_ataque: 1,
        bonus_armadura: 1,
    }

    const ITEM_ESPADA_CURVA = {
        bonus_ataque: 2,
        bonus_armadura: 1,
    }
    const ITEM_ESPADA_GRANDE = {
        bonus_ataque: 2,
        bonus_armadura: 1,
    }


    const ITEM_ARMADURA_LEVE = {
        bonus_ataque: 0,
        bonus_armadura: 1,
    }

    const ITEM_ARMADURA_MEDIA = {
        bonus_ataque: 0,
        bonus_armadura: 2,
    }

    const ITEM_ARMADURA_PESADA = {
        bonus_ataque: 0,
        bonus_armadura: 3,
    }
    const ITEM_BARBA_DIVINA = {
        cura_base: 5, 
    }
    const ITEM_CACHIMBO = {
        cura_extra: 5
    }

    var JOGADOR = {
        dinheiro: 50,
        vida: 20,
        armadura: 0,
        ataque: 1,
        item: null,
        itens: [],

        dano: (forca) => {
            let danototal = 0;
            if (JOGADOR.item) {
                danototal = forca - JOGADOR.item.bonus_armadura - JOGADOR.armadura; 
            } else {
                danototal = forca -JOGADOR.armadura;
            }

            if (danototal > 0) {
                JOGADOR.vida -= danototal;
            }
        },


        curar: () => {
            let cura = 0;
    
            // Se tiver a Barba Divina, começa com a cura base de 5
            if (JOGADOR.item && JOGADOR.item === ITEM_BARBA_DIVINA) {
                cura += ITEM_BARBA_DIVINA.cura_base;
            }
    
            // Adiciona o aumento de cura baseado na quantidade de Cachimbos no inventário
            const quantidadeCachimbos = JOGADOR.itens.filter(item => item === ITEM_CACHIMBO).length;
            cura += quantidadeCachimbos * 5;  // Cada Cachimbo aumenta a cura da Barba Divina em 5
    
            // Aplica a cura e não deixa a vida ultrapassar o máximo
            JOGADOR.vida += cura;
            if (JOGADOR.vida > 20) {  // Limite máximo de vida
                JOGADOR.vida = 20;
            }
        }
    };
    

    var MONSTRO = {
        vida: 10,
        maxVida: 10,
        armadura: 0,
        ataque: 1,
        item: null,
    }
    
    var BOSS = {
        vida: 25,
        armadura: 1, 
        ataque: 3,

    }
    
    
    // Definir a narrativa e opções
    const story = [
        {
            text: 'Você é um cidadão de Oarton, uma vila localizada no reino de Fahrul. Você trabalha como coveiro na cidade. Após um longo dia de trabalho, você volta para casa e, ao chegar lá, vê uma carta com o selo oficial da cidade fechando-a. Quando você abre ela, percebe que se trata de um chamado da própria rainha Rosomon, convocando-o para o castelo dela.',
            choices: [
                // opção 0
                { text: 'Explorar Oarton', next: 2 },
                { text: 'Explorar a floresta', next: 1 },
            ]
        },
        {
            text: 'Ao tentar sair da cidade, os guardas te barram no portão, dizendo que você não pode sair sem equipamentos, pois depois do início da Guerra do Caos, ficou muito perigoso andar por aí desprotegido. Você é obrigado a dar a volta. ',
            choices: [
                // opção 1
                { text: 'Explorar Oarton', next: 2 },
                 ]
        },
        {
            text: 'Voce decide ir visitar o ferreiro para conseguir novos equipamentos antes de ir se encontrar com a rainha',
            choices: [
                // opção 2
                { text: 'Visitar o ferreiro da cidade', next: 3, ganha_dinheiro: 20 }, // RETIRAR ISSO AQUI DEPOIS
                ]
        },
        
        {
            text: 'Você decide ir visitar o ferreiro para conseguir novos equipamentos. Lá voce encontra Cleber, o ferreiro. Ele te apresenta o arsenal dele.',
            choices: [
                // opção 3
                { text: 'Comprar Espada Curta e Escudo de Madeira (18 moedas)', next: 4, preco: 18, ganha: ITEM_ESPADA_ESCUDO },
                { text: 'Comprar Machado Antigo (13 moedas)', next: 4, preco: 13, ganha: ITEM_MACHADO }
            ]
        },
        {
            text: 'Após comprar seu equipamento, você decide ir visitar a rainha Rosomon.',
            choices: [
                // opção 4
                { text: 'Visitar a rainha no castelo', next: 5 },
                ]
        },
        {
            text: 'Você decide visitar a rainha no castelo para responder ao chamado dela. Quando voce chega, encontra com outros cidadãos que também foram chamados por ela. Ela aparece à vocês, muito triste com a morte de seu companheiro. Ela fala que o mago real desapareceu, e que o rei Bronner foi morto. Após isso, o reino de Fahrul mergulhou em caos. Ela manda vocês irem até a cidade vizinha de Torralenha para se encontrarem com Hildebrant, um fabricante de bebidas e ex-oficial do exército real. Ele passará mais informações sobre a busca pelo assassino do rei, pelo mago desaparecido e sobre a guerra contra o caos.  ',
            choices: [
                // opção 5
                { text: 'Sair do castelo', next: 6 }
            ]
        },
        {
            text: 'Após sair do castelo, você se vê com duas opções: visitar o ferreiro ou visitar o mercado. O que você faz?',
            choices: [
                // opção 6
                { text: 'Visitar o mercado', next: 7 },
                { text: 'Explorar a floresta', next: 8},
              ]
        },
        {
            text: 'Você decide visitar o mercado. Chegando lá, você encontra Eduardo, o mercador da cidade. Ele te oferece os seguintes itens... ',
            choices: [
                // opção 7
                { text: 'Barba divina (10 moedas)', next: 8, preco: 10, },
                { text: 'Cachimbo de olmo (25 moedas)', next: 8, preco: 25, ganha: ITEM_CACHIMBO },
                { text: 'Capa de Explorador (30 moedas)', next: 8, preco: 30, ganha: ITEM_ARMADURA_LEVE}
            ]
        },
        {
            text: 'Após comprar seus itens no mercado, o que você faz?',
            choices: [
                // opção 8
                { text: 'Explorar a floresta', next: 9 },
                
            ]
        },
        {
            text: 'Você volta ao centro de Oarton. Agora equipado e sabendo dos seus objetivos, você decide ir até a Floresta. Ao chegar no portão da cidade, os guardas te desejam boa sorte, e você parte para sua jornada.',
            choices: [
                // opção 9
                { text: 'Pegar a estrada até Torralenha', next: 10 },
                
            ]
        },
        {
            text: 'Você se dirige rapidamente até a cidade vizinha, Torralenha. O que você faz?',
            choices: [
                // opção 10
                { text: 'Explorar a cidade', next: 11 },
                { text: 'Ir embora', next: 5 }
            ]
        },
         {
            text: 'Ao explorar a cidade, você se depara com vários mercadores, mas o clima na cidade é de incerteza. Após o início da Guerra do Caos, as pessoas vivem com medo.',
            choices: [
                // opção 11
                { text: 'Ir até os mercadores e ver seus produtos', next: 12 },
                { text: 'Procurar por Hildebrant', next: 13 }
            ]
        },
        {
            text: 'Você se dirige até os mercadores e pede para ver seus produtos. Eles mostram o estoque para você',
            choices: [
                // opção 12
                { text: 'Barba Divina (10 moedas)', next: 11 },
                { text: 'Botas de Explorador (25 moedas)', next: 11 }
            ]
        },
        {
            text: 'Você se dirige ao centro da vila, e encontra Hildebrant. Você diz que foi enviado pela rainha para ajudar na luta contra o caos. Ele te diz que, para começar, você precisa derrotar um grupo de soldados do caos, e destruir um dispositivo que gera caos.',
            choices: [
                // opção 13
                { text: 'Ir até o dispositivo do caos', next: 14 },
                { text: 'Ir até o soldado do caos', next: 18 },  
            ]
        },
        {
            text: 'Você vai até o dispositivo do caos. Ao se aproximar, você se encontra com um hexagono roxo brilhante, com uma pérola ',
            choices: [
                // opção 14
                { text: 'Tentar destruir ele', next:  [16, 17]},
                { text: 'Se afastar e ir embora', next: 13 },  
            ]
        },
        {
            text: 'Você decide enfrentar o servo do caos. Ao chegar no acampamento dele, você encontra um soldado com uma armadura roxo resplandecente.  ',
            choices: [
                // opção 15
                { text: 'Entrar ', next: 17 },
                { text: 'Se afastar e ir embora', next: 13 },  
            ]
        },
        {
            text: 'Parabéns, você consegue destruir o dispositivo, diminuindo o caos.',
            choices: [
                // opção 16
                { text: 'Voltar para Torralenha ', next: 13 },
                { text: 'Ir atrás do Soldado do Caos', next: 18 },  
            ]
        },
        {
            text: 'Infelizmente você não conseguiu destruir. Perdeu 2 HP.',
            damage: 2,
            choices: [
                // opção 17
                { text: 'Tentar novamente. ', next: [16, 17],},
                { text: 'Se afastar e ir embora', next: 13 },  
            ]
        },
        {
            text: 'Você entra no acampamento do líder do caos, e ele se prepara para lutar com você. Você saca sua arma e parte para a luta.',
            choices: [
                // opção 18
                { text: 'Atacar', next: [19,20] },
                { text: 'Defender', next: 21 },  
            ]
        },
        {
            text: 'Seu ataque foi bem sucedido.', atacarMonstro:(JOGADOR.ataque),
            choices: [
                // opção 19
                { text: 'Atacar', next: [19,20] },
                { text: 'Defender', next: 21 },  
            ]
        },
        {
            text: 'Você errou o ataque, ficando vulnerável. Perdeu 2 HP', damage: 2,
            choices: [
                // opção 20
                { text: 'Atacar', next: [19,20] },
                { text: 'Defender', next: 21 },  
            ]
        },
        {
            text: 'Você monta guarda, se defendendo dos ataques',
            choices: [
                // opção 21
                { text: 'Atacar', next: [19,20] },
                { text: 'Defender', next: 21 },  
            ]
        },
        {
            text: 'Você consegue derrotar o Soldado do Caos, destruindo o seu acampamento e todas as fontes de caos.',
            choices: [
                // opção 22
                { text: 'Voltar para Torralenha', next: 23 },
                  
            ]
        },
        {
            text: 'Você volta para Torralenha.',
            choices: [
                // opção 23
                { text: 'Ir até o centro da cidade', next: 24 },
                  
            ]
        },
        {
            text: 'Você vai até o centro da cidade',
            choices: [
                // opção 24
                { text: 'Se encontrar com Hildebrant', next: 25 },
                { text: 'Ir até os mercadores e reabastecer', next: 26 }, 
            ]
        },
        {
            text: 'Você se encontra com Hildebrant. Ele te agradece, e diz que ainda é preciso destruir o principal gerador do caos, que fica nas Minas Brilhantes',
            choices: [
                // opção 25
                { text: 'Sair da cidade', next: 26 },
                { text: 'Ir até os mercadores e reabastecer', next: 27 }, 
            ]
        },
        
        {
            text: 'Você sai da cidade, e se dirige na direção da mina. Chegando lá, você vê uma forte luz roxa vindo de dentro dela, e sabe que realmente chegou no lugar certo.',
            choices: [
                // opção 26
                { text: 'Entrar na mina', next: 28 },
                { text: 'Dar meia volta e voltar para a cidade', next: 24 }, 
            ]
        },
        {
            text: 'Ao se encontrar com os mercadores, você percebe que eles estão admirados por você ter conseguido diminuir o caos. Eles te oferecem mais itens',
            choices: [
                // opção 27
                { text: 'Barba Divina (8 moedas)', next: 24, preco: 8, ganha: ITEM_BARBA_DIVINA },
                { text: 'Espada Curva (30 moedas)', next: 24, preco: 30, ganha: ITEM_ESPADA_CURVA },  
                { text: 'Peitoral de Couro (30 moedas)', next: 24, preco: 60, ganha: ITEM_ARMADURA_MEDIA},
            ]
        },
        {
            text: 'Você empunha sua arma, pega sua mochila, e entra na mina.',
            choices: [
                // opção 28
                { text: 'Ir para a próxima sala', next: 29 },
                
            ]
        },
        {
            text: 'Ao entrar na sala, você se depara com uma placa de pressão no chão. Ao olhar em volta, você vê diversos orifícios na parede. Claramente uma armadilha de flecha.',
            choices: [
                // opção 29
                { text: 'Tentar passar correndo', next: [30,31] },
                { text: 'Tentar desarmar a armadilha', next: [30,31] },
                
            ]
        },
        {
            text: 'Você falhou. Perdeu 2 HP',
            choices: [
                // opção 30
                { text: 'Ir para a próxima sala', next: 32 },
                
                
            ]
        },
        {
            text: 'Você conseguiu.',
            choices: [
                // opção 31
                { text: 'Ir para a próxima sala', next: 32 },
                               
            ]
        },
        {
            text: 'Ao ir para a próxima sala, você encontra vários esqueletos no chão, de aventureiros antigos. Você sabe que a missão que o aguarda será difícil. ',
            choices: [
                // opção 32
                { text: 'Ir para a próxima sala', next: 33,}
                               
                
            ]
        },
        {
            text: 'Ao abrir a porta da próxima sala, você se depara com um gigante. Ele deve ter mais que o dobro da sua altura, e segura uma enorme clava. Ele olha para você, e parte na sua direção',
            choices: [
                // opção 33
                { text: 'Atacar', next: [35, 36]},
                
                               
            ]
        },
        {
            text: 'Você defende o ataque do gigante', damage: 3,
            choices: [
                // opção 34
                { text: 'Atacar', next: [34, 35]},
                { text: 'Defender', next: 34,}
                               
            ]
        },
        {
            text: 'Você acerta o gigante em suas pernas, causando dano',
            choices: [
                // opção 35
                { text: 'Atacar', next: [34, 35]},
                { text: 'Defender', next: 34,}
                               
            ]
        },
        {
            text: 'Você consegue matar o gigante',
            choices: [
                // opção 36
                { text: 'Ir para a próxima sala', next: 37},                
                               
            ]
        },
        {
            text: 'Ao entrar na próxima sala, você vê um dispositivo brilhando uma luz roxa: um gerador do caos. ',
            choices: [
                // opção 37
                { text: 'Destruir ele', next: [38, 39]},                
                               
            ]
        },
        {
            text: 'Você consegue destruir o dispositivo do caos',
            choices: [
                // opção 38
                { text: 'Sair da mina', next: 40},                
                               
            ]
        },
        {
            text: 'Você não consegue destruir o dispositivo', damage: 2,
            choices: [
                // opção 39
                { text: 'Destruir ele', next: [38, 39]},  
            ]
        },
        { 
            text: 'Ao sair da mina, você volta para Torralenha e se encontra com Hildebrant. Ele diz que, com um dos principais geradores de caos destruídos, as chances de vencermos a Guerra do Caos aumentaram. Como próximo passo de sua missão, você é mandado se encontrar com Dreea Pallor, um informante da Coroa que mora em Parid, uma cidade em uma área desértica do reino. ',
            choices: [
                // opção 40 
                { text: 'Ir até Parid', next: 42},
                { text: 'Ir até os mercadores', next: 41},
            ]
        },
        { 
            text: 'Você vai até os mercadores. Eles estão muito agradecidos pelo seu trabalho, e te oferecem itens com desconto',
            choices: [
                // opção 41 
                { text: 'Barba Divina (6 moedas)', preco:6, next: 42},
                
            ]
        },
        {
        text: 'Você sai da cidade, e começa a viagem até Parid. No caminho para lá, você sente uma forte onda de calor, indicando que está chegando ao deserto.',
        choices: [
            // opção 42
            { text: 'Entrar na cidade', next: 43},
            
        ]
    },
    {
        text: 'Você entra em Parid. Ao passar pelo portão, você vê diversos mercadores vendendo produtos, desde ervas para tratar doenças até armas e armaduras.',
        choices: [
            // opção 43
            { text: 'Procurar por Dreea Pallor', next: 44},
            { text: 'Ir até os mercadores', next: 45},
        ]
    },
    {
        text: 'Você decide procurar por Dreea Pallor. Segundo as informações que te passaram, ela é uma mulher baixa, que veste sempre uma roupa preta, e anda com uma espada de cabo preto e vermelho. Ao caminhar pela cidade, você encontra uma mulher com essas mesmas características, e vai ao encontro dela. Ela se revela ser Dreea Pallor, ao você mostrar a carta com o selo da Rainha. Ela diz que seu próximo objetivo é destruir o grande gerador de caos que fica dentro do Labirinto do Rei, um lugar que muitos entraram, mas ninguém nunca saiu com vida. Para abrir esse labirinto, você precisa coletar três partes que formam a chave do labirinto, quando juntas. Essas três partes das chaves estão em três lugares diferentes: no acampamento do Lorde Mental, um dos mais poderosos magos do Exército do Caos, outra com o Lich, um antigo guerreiro que foi consumido pelas artes mágicas negras, e a outra está perdida em um antigo porão, e é guardada por um terrível monstro.',
        choices: [
            // opção 44
            { text: 'Ir até os mercadores', next: 45},
            { text: 'Sair da cidade', next: 46},
        ]
    },
    {
        text: 'Você vai até os mercadores, e eles te oferecem alguns produtos',
        choices: [
            // opção 45
            { text: 'Cimitarra (50 moedas)', preco: 50, next: 43, ganha: ITEM_ESPADA_GRANDE },
            { text: 'Armadura de Placa (80 moedas)', preco: 80, next: 43, ganha: ITEM_ARMADURA_PESADA },        
        ]
    },
    {
        text: 'Com três objetivos em mente, você deve decidir qual fazer primeiro.',
        choices: [
            // opção 46
            { text: 'Procurar pelo Porão Esquecido', next: 47},
            { text: 'Ir até a Cripta do Lich', next: 48},
            { text: 'Ir até o Lorde Mental', next: 49},
        ]
    },
    {
        text: 'Você decide começar a procurar o Porão Esquecido. Ao procurar por um tempo nas proximidades, você se depara com uma pequena casinha. Ao abrir a porta, você encontra uma escada descendo para um porão.',
        choices: [
             // opção 47
             { text: 'Descer a escada e entrar no Porão', next: 50 },
             { text: 'Dar meia volta e ir embora', next: 46},

        ]

    },
    {
        text: 'Você decide ir derrotar o Lich. Ao caminhar até o cemitério, você observa uma cripta com uma caveira desenhada na porta.',
        choices: [
             // opção 48
             { text: 'Abrir a porta e entrar na Cripta', next: 51 },
             { text: 'Dar meia volta e ir embora', next: 46},

        ]

    },
    {
        text: 'Você decide ir atrás do Lorde Mental. Ao caminhar até a localização de seu acampamento, você se depara com diversas pessoas loucas, frutos dos experimentos de controle mental dele.',
        choices: [
             // opção 49
             { text: 'Entrar no acampamento', next: 52 },
             { text: 'Dar meia volta e ir embora', next: 46},

        ]

    },
    {
        text: 'Ao descer no porão, você vê um cubo de geléia ácida guardando a chave. Ao ver você, ela pula em sua direção, mas você consegue desviar do ataque. Você puxa sua arma, e se prepara para lutar',
        choices: [
             // opção 50
             { text: 'Atacar', next: [53, 54] },
             

        ]

    },
    {
        text: 'Ao abrir a porta da Cripta, você se depara com diversos esqueletos no chão, provavelmente de antigos aventureiros. ',
        choices: [
             // opção 51
             { text: 'Ir para a próxima sala', next: 50}

        ]

    },
    {
        text: 'Ao entrar no acampamento do Lorde Mental, você saca sua arma e vai até a direção da tenda principal. Ao chegar lá, você o vê fazendo um de seus experimentos, mas ele rapidamente se vira em sua direção e lança uma de suas magias. Você desvia dela, e se prepara para a luta enquanto ele sai de dentro da sua tenda',
        choices: [
             // opção 52
             { text: 'Atacar', next: [55, 56]},
             
        ]

    },
    {
        text: 'Você acerta o ataque',
        choices: [
             // opção 53
             { text: 'Atacar', next: [55, 56]},
             
        ]

    },
    {
        text: 'Você erra o ataque, ficando vulnerável', damage: 3,
        choices: [
             // opção 54
             { text: 'Atacar', next: [55, 56]},
              ]

    },
    {
        text: 'Você acerta o ataque',
        choices: [
             // opção 55
             { text: 'Atacar', next: [55, 56]},
             { text: 'Defender', next: [57]},
        ]

    },
    {
        text: 'Você erra o ataque, ficando vulnerável', damage: 3,
        choices: [
             // opção 55
             { text: 'Atacar', next: [55, 56]},
             { text: 'Defender', next: [57]},
        ]

    },
    
    
    ];
    
    

    

    let currentStep = 0;
    var entidades = [];
    
    ;

    function showStory(step) {

     

        
        
    }
    
    
    entidades.push(JOGADOR);

    function showStory(step) {

        storyText.textContent = story[step].text;
        choicesContainer.innerHTML = '';
        vidasContainer.innerHTML = '';
        entidades.forEach(entidades => {
            barra = document.createElement('progress');
            barra.max = 20;
            barra.value = entidades.vida;
            vidasContainer.appendChild(barra);
        })

        
        if (story[step].damage) {
            JOGADOR.dano(story[step].damage);
        }

        

        story[step].choices.forEach(choice => {
            const button = document.createElement('button');
            button.textContent = choice.text;
            button.classList.add('choice-button');

            if (choice.preco) {
                if (choice.preco > JOGADOR.dinheiro) {
                    button.disabled = true;
                }
            }

            button.addEventListener('click', () => {
                if (choice.next !== null) {

                    if (typeof(choice.next) == 'number') {
                        currentStep = choice.next;
                    } else {
                        currentStep = choice.next[Math.floor(Math.random() * choice.next.length)];
                    }
                    if (choice.damage) {
                        JOGADOR.vida -= choice.damage;
                    }
                    if (choice.ganha) {
                        JOGADOR.item = choice.ganha;
                    }
                    if (choice.preco) {
                        JOGADOR.dinheiro -= choice.preco;
                    }
                    if (choice.ganha_dinheiro) {
                        JOGADOR.dinheiro += choice.ganha_dinheiro;
                    }
                    if (choice.vida) {
                        JOGADOR.vida += choice.vida;
                    }  
                    
                    console.log(JOGADOR);
                    // Exibir a nova vida do monstro para debug (opcional)
                    console.log("A vida do monstro agora é: " + MONSTRO.vida);
                    showStory(currentStep);
                } else {
                    alert('Obrigado por jogar!');
                    // Opcional: Reiniciar o jogo ou fazer outra ação
                }
            });
            choicesContainer.appendChild(button);
        });
    }

    

    // Iniciar o jogo
    showStory(currentStep);
});
